package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.EmployeeRegister;
import Bean.Login;
import Bean.Register;
import Dao.maindao;



/**
 * Servlet implementation class kompServlet
 */
@WebServlet("/kompServlet")
public class kompServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public kompServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String action=request.getParameter("action");
		Register robj=new Register();
		if(action.equals("register"))
		{

		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String purpose_of_visit=request.getParameter("purpose");
		String person_to_visit=request.getParameter("person");
		robj.setName(name);
		robj.setEmail(email);
		robj.setPhone(phone);
		robj.setPurpose(purpose_of_visit);
		robj.setPerson(person_to_visit);
		maindao dreg=new maindao();
		String ok=dreg.Userreg(robj);
		if(ok.equals("SUCCESS"))
		{
		request.getRequestDispatcher("success.jsp").forward(request, response);
		}
		}
		if(action.equals("employeeregister"))
		{
			EmployeeRegister er=new EmployeeRegister();
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String dob=request.getParameter("dob");
		String phone=request.getParameter("phone");
		String qualification=request.getParameter("qualification");
		String skillset=request.getParameter("skillset");
		String department=request.getParameter("department");
		String role=request.getParameter("role");
		String dateofjoining=request.getParameter("dateofjoining");
		String permanentaddress=request.getParameter("permanentaddress");
		String temporaryaddress=request.getParameter("temporaryaddress");
		er.setName(name);
		er.setEmail(email);
		er.setPassword(password);
		er.setDob(dob);
		er.setPhone(phone);
		er.setQualification(qualification);
		er.setSkillset(skillset);
		er.setDepartment(department);
		er.setRole(role);
		er.setDateofjoining(dateofjoining);
		er.setPermanent(permanentaddress);
		er.setTemporary(temporaryaddress);
		
		maindao dreg=new maindao();
		String ok=dreg.Empreg(er);
		if(ok.equals("SUCCESS"))
		{
		request.getRequestDispatcher("success.jsp").forward(request, response);
		}
		}
	
	if(action.equals("login"))
	{
		Login lg=new Login();
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		lg.setName(name);
		lg.setPassword(password);
		maindao dreg=new maindao();
		String ok=dreg.Emplogin(lg);
		if(ok.equals("tech"))
		{
			request.getRequestDispatcher("success.jsp").forward(request, response);	
		}
	}
	
	if(action.equals("studentlist"))
	{
		maindao obj2=new maindao();
		ArrayList<Register> reg=obj2.getInfo();
		HttpSession ses=request.getSession();
		ses.setAttribute("userlist", reg);
		request.getRequestDispatcher("view.jsp").forward(request, response);
		
	}
	if(action.equals("submit"))
	{
	String id=request.getParameter("id");	
	String status=request.getParameter("join");
	Register reg=new Register();
	reg.setId(id);
	reg.setStatus(status);
	maindao dao= new maindao();
	String ok=dao.updatestatus(reg);
	if(ok.equals("Success"))
	{
		request.getRequestDispatcher("success.jsp").forward(request, response);	
	}
		
	}

}
}
