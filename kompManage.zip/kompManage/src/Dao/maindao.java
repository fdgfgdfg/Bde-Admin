package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Bean.EmployeeRegister;
import Bean.Login;
import Bean.Register;

public class maindao {
	Dbconnect dobj=new Dbconnect();
	Connection con=dobj.Dbconnect();
	Statement st=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	public String Userreg(Register robj)
	{
	try{
	String add= "insert into registration(name,email,phone,purpose_of_visit,person_to_visit,date)values(?,?,?,?,?,curdate())";
	con=dobj.Dbconnect();
	ps=con.prepareStatement(add);
	ps.setString(1,robj.getName());
	ps.setString(2,robj.getEmail());
	ps.setString(3,robj.getPhone());
	ps.setString(4,robj.getPurpose());
	ps.setString(5,robj.getPerson());
	int i=ps.executeUpdate();
	if(i!=0)
	{
	return "SUCCESS";
	}
	else
	{
	return "NOT SUCCESS";
	}
	}
	catch(Exception e)
	{
	System.out.println(e);
	}
	return null;


	}
	public String Empreg(EmployeeRegister er)
	{
	try{
	String add= "insert into employee(name,email,phone,dob,qualification,permenent_address,temporary_address,skill_set,department,date_of_joining,role,password)values(?,?,?,?,?,?,?,?,?,?,?,?)";
	con=dobj.Dbconnect();
	ps=con.prepareStatement(add);
	ps.setString(1,er.getName());
	ps.setString(2,er.getEmail());
	ps.setString(3,er.getPhone());
	ps.setString(4,er.getDob());
	ps.setString(5,er.getQualification());
	ps.setString(6,er.getPermanent());
	ps.setString(7,er.getTemporary());
	ps.setString(8,er.getSkillset());
	ps.setString(9,er.getDepartment());
	ps.setString(10,er.getDateofjoining());
	ps.setString(11,er.getRole());
	ps.setString(12,er.getPassword());
	
	int i=ps.executeUpdate();
	if(i!=0)
	{
	return "SUCCESS";
	}
	else
	{
	return "NOT SUCCESS";
	}
	}
	catch(Exception e)
	{
	System.out.println(e);
	}
	return null;

	}

	public String Emplogin(Login obj)
	{
		String name=obj.getName();
		String password=obj.getName();
		try
		{
		String get="select * from employee";
		ps=con.prepareStatement(get);
	    rs=ps.executeQuery();
	     while(rs.next())
	     {
	     String dbname=rs.getString("name");
	     String dbpassword=rs.getString("password");
	     String dbdepartment=rs.getString("department");
	     
		if(name.equals(dbname)&&password.equals(dbpassword))
		{
			
			if(dbdepartment.equals("tech"))
			{
				return "tech";
			}
		}
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
		
		
	}
	
	public ArrayList<Register> getInfo()
	{
		ArrayList<Register> list=new ArrayList<Register>();
		try
		{
			String view="select * from registration";
			ps=con.prepareStatement(view);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Register ob=new Register();
				ob.setId(rs.getString("id"));
				ob.setName(rs.getString("name"));
				ob.setEmail(rs.getString("email"));
				ob.setPhone(rs.getString("phone"));
				ob.setPurpose(rs.getString("purpose_of_visit"));
				ob.setPerson(rs.getString("person_to_visit"));
				list.add(ob);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return list;
		
	}
	public String updatestatus(Register reg)
	
	{
		try{
			String add="update registration set status=? where id='"+reg.getId()+"'";
			con=dobj.Dbconnect();
			ps=con.prepareStatement(add);
			ps.setString(1,reg.getStatus());
			int i=ps.executeUpdate();
			if(i!=0)
			{
			return "SUCCESS";
			}
			else
			{
			return "NOT SUCCESS";
			}
			
		}
	catch(Exception e)
	{
		System.out.println(e);
	}
		return null;
		
		
	}
	
}
